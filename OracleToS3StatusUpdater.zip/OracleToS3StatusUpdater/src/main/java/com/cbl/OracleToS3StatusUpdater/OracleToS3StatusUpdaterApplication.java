package com.cbl.OracleToS3StatusUpdater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleToS3StatusUpdaterApplication {

	public static void main(String[] args) {
		SpringApplication.run(OracleToS3StatusUpdaterApplication.class, args);
	}

}
