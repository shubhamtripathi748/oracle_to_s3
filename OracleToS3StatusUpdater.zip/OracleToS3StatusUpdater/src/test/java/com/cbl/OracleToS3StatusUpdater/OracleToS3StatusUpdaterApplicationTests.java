package com.cbl.OracleToS3StatusUpdater;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OracleToS3StatusUpdaterApplicationTests {

	@Test
	void contextLoads() {
	}

}
